#Important Constants used throughout

#Type of space
BLANK_STATE    = 0
START_STATE    = 1
GOAL_STATE     = 2
POTHOLE_STATE  = 3
ROCKFALL_STATE = 4

#Upper Limits
X_LIM = 3
Y_LIM = 3
